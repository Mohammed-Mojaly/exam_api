<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PostController;

Route::group(['middleware' => 'api', 'prefix' => 'auth'], function ($router) {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::get('/profile', [AuthController::class, 'userProfile']);



    Route::controller(PostController::class)->group(function () {
        Route::get('/posts', [PostController::class, 'index']);
        Route::get('/posts/user-posts', [PostController::class, 'user_posts']);
        Route::get('/posts/search', [PostController::class, 'search']);
        Route::get('/posts/by-tags', [PostController::class, 'posts_by_tags']);
        Route::get('/posts/{id}', [PostController::class, 'get_post']);

        Route::post('/posts/create', [PostController::class, 'store']);
        Route::post('/posts/update/{post}', [PostController::class, 'update']);
        Route::delete('/posts/delete/{post}', [PostController::class, 'distroy']);

    });
});
